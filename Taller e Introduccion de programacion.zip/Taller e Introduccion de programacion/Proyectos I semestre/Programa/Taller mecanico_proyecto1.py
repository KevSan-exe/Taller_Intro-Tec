#Proyecto #1 Taller de programacion.
#Taller mecanico

#######################################################################################################################################################################
 
#menu principal
#E:una opcion definida por numero
#S:la redireccion a una funcion
#R:las opciones deben ser representadas con numeros

def taller_mecanico():  
    print("Bienvenido al menu principal.\n1. Opciones administrativas.\n2. Opciones generales.\n3. Salir.")
    return select_0()
#redirecciones del menu principal
def select_0():
    select_menu=input("Que tarea desea realizar: ")
    if select_menu=="1":
        return ingreso()
    elif select_menu=="2":
        return opciones_generales()
    elif select_menu=="3":
        print("")
        print("Gracias por utilizar el programa.")
    else:
        print("")
        print("La opcion ingresada no es valida.")
        return select_0()

#######################################################################################################################################################################

#verificacion de clave de ingreso 
#E:una contrasena
#S:si la contrasena es correcta te envia a opciones administrativas sino permite volverla a ingresar
#R:

def ingreso():
    print("")
    log_in=input("Ingrese una clave de ingreso: ")
    clave="qwerty123" #aqui puede modificar la clave de ingreso
    if log_in==clave:
        return opciones_admi()
    else:
        print("La clave ingresada es incorrecta, intentelo de nuevo")
        return ingreso()

#######################################################################################################################################################################

#opciones administrativas    
#E:una opcion definida por numero
#S:la redireccion a una funcion
#R:las opciones deben estar representadas por numeros

def opciones_admi():
    print('')
    print("Opciones administrativas\n1. Gestión de tipo de vehículo\n2. Gestión de repuestos\n3. Gestión de actividades de mano de obra\n4. Gestión de planes de mantenimiento\n5. Gestión de reparaciones\n6. Facturacion\n7. Volver")
    return select_1()

def select_1():
    select_menu=input("Que tarea desea realizar: ")
#redireccion opciones administrativas
    if select_menu=="1":
        return gestion_tipo()
    elif select_menu=="2":
        return gestion_repuesto()
    elif select_menu=="3":
        return gestion_mano()
    elif select_menu=="4":
        return gestion_planes()
    elif select_menu=="5":
        return gestion_reparacion()
    elif select_menu=="6":
        return facturar()
    elif select_menu=="7":
        print('')
        return taller_mecanico()
    else:
        print("La opcion ingresada no es valida")
        return select_1()

#######################################################################################################################################################################

#menu de gestion de tipo
#E:una tarea a realizar
#S:la redirecion a la realizacion de la tarea
#R:las opciones deben ser representadas por numeros
    
def gestion_tipo():
    print('')
    print("Gestión de tipo de vehículo\n1.Incluir tipo de vehículo\n2.Eliminar tipo de vehículo\n3.Modificar tipo de vehiculo\n4.Volver")
    return gestion1()

#redirecciones gestion de tipo de vehiculo
def gestion1():
    select_menu=input("Que tarea desea realizar: ")
    if select_menu=="1":
        return incluir_tipo()
    elif select_menu=="2":
        return eliminar_tipo()
    elif select_menu=="3":
        return modificar_tipo()
    elif select_menu=="4":
        return opciones_admi()
    else:
        print("La tarea ingresada no es valida")
        return gestion1()

#######################################################################################################################################################################

#incluir un vehiculo al texto en que se almacenan
#E:descripcion del tipo, cantidad de pasajeros y cantidad de ejes del vehiculo
#S:el almacenamiento de la informacion ingresada en el txt solicitado
#R:no pueden existir dos tipos iguales
def incluir_tipo():
    mostrar_tipo()
    print("Incluir tipo de vehículo")
    tipo=(input("Ingrese el tipo de vehiculo: "))
    pasajero=(input("Ingrese la cantidad de pasajeros del vehiculo: "))
    ejes=(input("Ingrese la cantidad de ejes del vehiculo: "))
    archivo=open("GestionVehiculo.txt","a")
    incluir(tipo,pasajero,ejes,archivo)
    print('')
    print("Se anadio con exito el tipo de vehiculo",tipo,"con cantidad de pasajeros",pasajero,"y con",ejes,"ejes.")
    mostrar_tipo()
    return gestion_tipo()

#######################################################################################################################################################################

#guardar en el archivo
#E:tres inputs y un archivo abierto
#S:los inputs guardados en el archivo
#R:los archivos se deben guardar como strings

def incluir(x,y,z,archivo):
    archivo.write(x)
    archivo.write(",")
    archivo.write(y)
    archivo.write(",")
    archivo.write(z)
    archivo.write("\n")
    archivo.close()

#######################################################################################################################################################################

#eliminar un tipo de vehiculo del texto en que se almacena
#E:la descripcion del tipo,
#S:la eliminacion de el tipo de vehiculo del archivo
#R:no se puede eliminar tipos asociados a una reservacion ni tipos con el mismo nombre

def eliminar_tipo():
    mostrar_tipo()
    print("Eliminar tipo de vehículo")
    tipo=input("Ingrese el tipo de vehiculo que desea eliminar: ")
    return eliminar1(tipo)

def eliminar1(tipo):
    archivo=open("GestionVehiculo.txt","r")
    listatxt=archivo.readlines()
    lista=limpiarlista(listatxt,[])
    if esta(lista,tipo,0):
        nuevo=eliminar(lista,tipo,0,False)
        archivo2=open("GestionVehiculo.txt","w")
        save(nuevo,0,archivo2)
        print("Se elimino el tipo de vehiculo",tipo,".")
        mostrar_tipo()
        return gestion_tipo()
    else:
        print("El tipo que desea eliminar no se encuentra almacenado")
        mostrar_tipo()
        return gestion_tipo()

#######################################################################################################################################################################

#funciones requeridas para eliminar elementos de el archivo deseado

#transforma a matriz lo que se encuentra en el archivo
def limpiarlista(lista,res):
    if lista==[]:
        return res
    else:
        caso=lista[0].rstrip()
        caso2=caso.split(",")
        res+=[caso2]
        return limpiarlista(lista[1:],res)

#elimina el elemento deseado
def eliminar(lista,tipo,pos,delete):
    if delete:
        return lista
    else:
        if (lista[pos][0]==tipo):
            lista=lista[0:pos]+lista[pos+1:]
            return eliminar(lista,tipo,pos,True)
        else:
            return eliminar(lista,tipo,pos+1,delete)

#verifica si se encuentra un elemento en la matriz
def esta(lista,tipo,pos):
    if pos>largo(lista)-1:
        return False
    else:
        if lista[pos][0]==tipo:
            return True
        else:
            return esta(lista,tipo,pos+1)

#permite escribir en el archivo de texto
def save(lista,pos,archivo):
    if pos>largo(lista)-1:
        archivo.close()
    else:
        archivo.write(lista[pos][0]+","+lista[pos][1]+","+lista[pos][2])
        archivo.write("\n")
        return save(lista,pos+1,archivo)

##Funcion de largo de matriz
def largo(lista):
        return largo_aux(lista, 0)
def largo_aux(lista, res):
    if lista==[]:
        return res
    else:
        return largo_aux(lista[1:],1+res)
    
#######################################################################################################################################################################

#E:los datos que se desean modificar con los nuevos datos
#S:la modificacion de los datos en el archivo de almacenamiento
#R:se debe ingresar los datos exactos de que se desea eliminar 
    
def modificar_tipo():
    mostrar_tipo()
    print("Modificar tipo de vehículo")  
    tipo=input("Ingrese el tipo de vehiculo que desea modificar: ")
    pasajeros=input("Ingrese la cantidad de pasajeros: ")
    ejes=input("Ingrese la cantidad de ejes: ")

    archivo=open("GestionVehiculo.txt","r")
    listatxt=archivo.readlines()
    lista=limpiarlista(listatxt,[])
    if esta(lista,tipo,0):
        print('')
        modi_tipo=input("Ingrese el nuevo tipo de vehiculo: ")
        modi_pasajeros=input("Ingrese la nueva cantidad de pasajeros: ")
        modi_ejes=input("Ingrese la nueva cantidad de ejes: ")
        nuevo=[modi_tipo,modi_pasajeros,modi_ejes]
        lugar=posicion(lista,[tipo,pasajeros,ejes],0)
        archivo2=open("GestionVehiculo.txt","w")
        modificar(lista,lugar,nuevo,0,archivo2)
        print('')
        print("Se modifico el tipo de vehiculo",tipo,",",pasajeros,"pasajeros y",ejes,"ejes con el tipo",modi_tipo,"de",modi_pasajeros,"pasajeros y",modi_ejes,"ejes")
        mostrar_tipo()
        return gestion_tipo()
    else:
        print("El tipo que desea modificar no se encuentra almacenado")
        mostrar_tipo()
        return gestion_tipo()

#######################################################################################################################################################################

#funciones requeridas para modificar

def posicion(lista,tipo,pos):
    if lista==[]:
        return False
    else:
        if lista[0]==tipo:
            return pos
        else:
            return posicion(lista[1:],tipo,pos+1)
    
def modificar(lista,lugar,modificacion,pos,archivo):
    if pos>largo(lista)-1:
        archivo.close()
    else:
        if pos==lugar:
            archivo.write(modificacion[0]+","+modificacion[1]+","+modificacion[2])
            archivo.write("\n")
            return modificar(lista,lugar,modificacion,pos+1,archivo)
        else:
            archivo.write(lista[pos][0]+","+lista[pos][1]+","+lista[pos][2])
            archivo.write("\n")
            return modificar(lista,lugar,modificacion,pos+1,archivo)

#######################################################################################################################################################################

#mostrar lo que esta almacenado en el archivo
#E:el archivo abierto
#S:printeo de la informacion del archivo
#R:si el archivo esta vacio muestra un espacio en blanco

def mostrar_tipo():
    print('')
    print("Tipos almacenados")
    doc=open("GestionVehiculo.txt","r")
    archivo=doc.read()
    return mostrar(archivo,doc)

def mostrar(archivo,doc):
    print(archivo)
    doc.close()

#######################################################################################################################################################################        

#menu de gestion de repuestos
#E:una tarea a realizar
#S:la redirecion a la realizacion de la tarea
#R:las opciones deben ser representadas por numeros

def gestion_repuesto():
    print('')
    print("Gestión de repuesto\n1.Incluir repuesto\n2.Eliminar repuesto\n3.Modificar repuesto\n4.Volver")
    return gestion_repuesto_menu()

def gestion_repuesto_menu():
    select_menu=input("Que tarea desea realizar: ")
    if select_menu=="1":
        return incluir_repuesto()
    elif select_menu=="2":
        return eliminar_repuesto()
    elif select_menu=="3":
        return modificar_repuesto()
    elif select_menu=="4":
        return opciones_admi()
    else:
        print("La tarea ingresada no es valida")
        return gestion_repuesto_menu()

#######################################################################################################################################################################

#incluir un repuesto al texto en que se almacenan
#E:un repuesto, el costo de compra y precio de venta
#S:el almacenamiento de la informacion ingresada en el txt solicitado
#R:no pueden existir dos repuestos iguales
def incluir_repuesto():
    mostrar_repuesto()
    print("Incluir repuesto")
    tipo=(input("Ingrese el Repuesto: "))
    pasajero=(input("Ingrese el costo de compra: "))
    ejes=(input("Ingrese el precio de venta: "))
    archivo=open("GestionRepuesto.txt","a")
    incluir(tipo,pasajero,ejes,archivo)
    print('')
    print("Se anadio con exito el repuesto",tipo,"con el costo de compra",pasajero,"y precio de venta de",ejes,".")
    mostrar_repuesto()
    return gestion_repuesto()

#######################################################################################################################################################################

#eliminar un repuesto que se almacena
#E:la descripcion del repuesto
#S:la eliminacion del repuesto del archivo
#R:no se puede eliminar repuestos asociados a una reservacion ni tipos con el mismo nombre

def eliminar_repuesto():
    mostrar_repuesto()
    print("Eliminar repuesto")
    tipo=input("Ingrese el repuesto que desea eliminar: ")
    return eliminar2(tipo)

def eliminar2(tipo):
    archivo=open("GestionRepuesto.txt","r")
    listatxt=archivo.readlines()
    lista=limpiarlista(listatxt,[])
    if esta(lista,tipo,0):
        nuevo=eliminar(lista,tipo,0,False)
        archivo2=open("GestionRepuesto.txt","w")
        save(nuevo,0,archivo2)
        print("Se elimino el repuesto",tipo,".")
        mostrar_repuesto()
        return gestion_repuesto()
    else:
        print("El repuesto que desea eliminar no se encuentra almacenado")
        mostrar_repuesto()
        return gestion_repuesto()

#######################################################################################################################################################################

#mostrar lo que esta almacenado en el archivo
#E:el archivo abierto
#S:printeo de la informacion del archivo
#R:si el archivo esta vacio muestra un espacio en blanco

def mostrar_repuesto():
    print('')
    print("Repuestos almacenados")
    doc=open("GestionRepuesto.txt","r")
    archivo=doc.read()
    return mostrar(archivo,doc)

#######################################################################################################################################################################

#E:el repuesto que se desea eliminar, con el costo y el precio junto a los datos con los que lo desea modificar 
#S:el archivo con lo deseado modificado
#R:se deben incluir los valores exactos de lo que se desea eliminar

def modificar_repuesto():
    mostrar_repuesto()
    print("Modificar repuesto")  
    tipo=input("Ingrese el repuesto que desea modificar: ")
    pasajeros=input("Ingrese el costo de compra: ")
    ejes=input("Ingrese elprecio de venta: ")

    archivo=open("GestionRepuesto.txt","r")
    listatxt=archivo.readlines()
    lista=limpiarlista(listatxt,[])
    if esta(lista,tipo,0):
        print('')
        modi_tipo=input("Ingrese el nuevo repuesto: ")
        modi_pasajeros=input("Ingrese el nuevo costo de compra: ")
        modi_ejes=input("Ingrese el nuevo precio de venta: ")
        nuevo=[modi_tipo,modi_pasajeros,modi_ejes]
        lugar=posicion(lista,[tipo,pasajeros,ejes],0)
        archivo2=open("GestionRepuesto.txt","w")
        modificar(lista,lugar,nuevo,0,archivo2)
        print('')
        print("Se modifico el repuesto",tipo,"con el costo de compra de",pasajeros,"y con precio de venta",ejes,"con el repuesto",modi_tipo,"con el nuevo costo de compra de",modi_pasajeros,"y con el nuevo precio de venta de",modi_ejes,".")
        mostrar_repuesto()
        return gestion_repuesto()
    else:
        print("El repuesto que desea modificar no se encuentra almacenado")
        mostrar_repuesto()
        return gestion_repuesto()

#######################################################################################################################################################################

#menu mano de obra
#E:una tarea a realizar
#S:la redirecion a la realizacion de la tarea
#R:las opciones deben ser representadas por numeros

def gestion_mano():
    print('')
    print("Gestión de actividades de mano de obra\n1.Incluir actividad de mano de obra\n2.Eliminar actividad de mano de mano de obra\n3.Modificar actividad de mano de obra\n4.Volver")
    return gestion_mano_menu()

#redirecciones gestion de tipo de vehiculo
def gestion_mano_menu():
    select_menu=input("Que tarea desea realizar: ")
    if select_menu=="1":
        return incluir_mano()
    elif select_menu=="2":
        return eliminar_mano()
    elif select_menu=="3":
        return modificar_mano()
    elif select_menu=="4":
        return opciones_admi()
    else:
        print("La tarea ingresada no es valida")
        return gestion_mano_menu()

#######################################################################################################################################################################

#menu incluir actividades de mano de obra
#E:el nombre de la actividad, el tiempo de ejecucion y el precio del servicio
#S:los elementos ingresados guardados en el archivo correspondiente
#R:no pueden actividades con el mismo nombre

def incluir_mano():
    mostrar_mano()
    print("Incluir actividad de mano de obra")
    tipo=(input("Ingrese el nombre de la actividad: "))
    pasajero=(input("Ingrese el tiempo de ejecucion de la actividad: "))
    ejes=(input("Ingrese el precio del servicio: "))
    archivo=open("GestionMano.txt","a")
    incluir(tipo,pasajero,ejes,archivo)
    print('')
    print("Se anadio con exito la actividad",tipo,"con un tiempo de ejecucion de",pasajero,"y con el precio",ejes,".")
    mostrar_mano()
    return gestion_mano()

#######################################################################################################################################################################

#eliminar una actividad del texto en que se almacena
#E:la descripcion de la actividad
#S:la eliminacion de el tipo de vehiculo del archivo
#R:no se puede eliminar actividades asociados a una reparacion ni tipos con el mismo nombre

def eliminar_mano():
    mostrar_mano()
    print("Eliminar actividad de mano de obra")
    tipo=input("Ingrese la actividad que desea eliminar: ")
    return eliminar3(tipo)

def eliminar3(tipo):
    archivo=open("GestionMano.txt","r")
    listatxt=archivo.readlines()
    lista=limpiarlista(listatxt,[])
    if esta(lista,tipo,0):
        nuevo=eliminar(lista,tipo,0,False)
        archivo2=open("GestionMano.txt","w")
        save(nuevo,0,archivo2)
        print("Se elimino la actividad",tipo,".")
        mostrar_mano()
        return gestion_mano()
    else:
        print("La actividad que desea eliminar no se encuentra almacenado")
        mostrar_mano()
        return gestion_mano()
    
#######################################################################################################################################################################


#E:el repuesto que se desea eliminar, con el costo y el precio junto a los datos con los que lo desea modificar 
#S:el archivo con lo deseado modificado
#R:se deben incluir los valores exactos de lo que se desea eliminar

def modificar_mano():
    mostrar_mano()
    print("Modificar actividades de mano de obra")  
    tipo=input("Ingrese la actividad que desea modificar: ")
    pasajeros=input("Ingrese el tiempo de ejecucion: ")
    ejes=input("Ingrese el precio del servicio: ")

    archivo=open("GestionMano.txt","r")
    listatxt=archivo.readlines()
    lista=limpiarlista(listatxt,[])
    if esta(lista,tipo,0):
        print('')
        modi_tipo=input("Ingrese la nueva actividad: ")
        modi_pasajeros=input("Ingrese el nuevo tiempo de ejecucion: ")
        modi_ejes=input("Ingrese el precio del servicio: ")
        nuevo=[modi_tipo,modi_pasajeros,modi_ejes]
        lugar=posicion(lista,[tipo,pasajeros,ejes],0)
        archivo2=open("GestionMano.txt","w")
        modificar(lista,lugar,nuevo,0,archivo2)
        print('')
        print("Se modifico la actividad",tipo,"con el tiempo de ejecucion",pasajeros,"y con el precio",ejes,"con la actividad",modi_tipo,"con el nuevo tiempo de",modi_pasajeros,"y con el nuevo precio de",modi_ejes,".")
        mostrar_mano()
        return gestion_mano()
    else:
        print("La actividad que desea modificar no se encuentra almacenado")
        mostrar_mano()
        return gestion_mano()

#######################################################################################################################################################################

#mostrar lo que esta almacenado en el archivo
#E:el archivo abierto
#S:printeo de la informacion del archivo
#R:si el archivo esta vacio muestra un espacio en blanco

def mostrar_mano():
    print('')
    print("Actividades de mano de obra almacenadas")
    doc=open("GestionMano.txt","r")
    archivo=doc.read()
    return mostrar(archivo,doc)

#######################################################################################################################################################################    

def gestion_planes():
    print('')
    print("Esta tarea no se encuentra disponible")
    return opciones_admi()

def gestion_reparacion():
    print('')
    print("Esta tarea no se encuentra disponible")
    return opciones_admi()

def facturar():
    print('')
    print("Esta tarea no se encuentra disponible")
    return opciones_admi()


#######################################################################################################################################################################    
def opciones_generales():
    print('')
    print("Este menu no se encuentra disponible")
    print('')
    return taller_mecanico()
#######################################################################################################################################################################    
taller_mecanico()
