from tkinter import*

#Aqui estan las configuraciones de la ventana
ventana=Tk()
ventana.title("Calculadora")  
ventana.resizable(False,False) #no se podra cambiar el tamaNo de la ventana
ventana.iconbitmap("Calculadora_icono.ico") #el icono de la ventana
ventana.config(bg="#FFF5AC")

valor=""
texto=StringVar()

#=======================================================================
#E:botones
#S:la representacion de el valor de los botones
#R:solo es invocadi=o cuando se da click en el boton
def click(num):
    global valor
    valor= valor+str(num)
    texto.set(valor)

#=======================================================================
#E:boton adjunto a la funcion
#S:el textbox borrado en su totalidad
#R:solo es invocado se se le da click al boton adjunto a la funcion
def clear_all():
    global valor
    valor=""
    texto.set("")

#=======================================================================
#E:boton adjunto a la funcion
#S:la operacion que se ha ingresado
#R:Se debe notar de un error si se presenta
def resultado():
    global valor
    if valor=="":
        texto.set("")
    else:
        try:
            igual=str(eval(valor))
            texto.set(igual)
        except:
            error=("ERROR")
            texto.set(error)

#=======================================================================
#E:elementos ingresados
#S:la eliminacion del ultimo elemento
#R:solo puede eliminar un elemento a la vez
def eliminar():
    global valor
    largo_delete=largo(valor,0)
    valor=valor[:largo_delete-1]
    texto.set(valor)

def largo(valor,res):
    if valor=="":
        return res
    else:
        return largo(valor[1:],res+1)
#======================================================================

#textbox en donde se mostraran los numeros y operaciones elegidas
textbox=Entry(ventana,width=35,textvariable=texto,bd=10,insertwidth=1,justify="right")
textbox.grid(column=1,row=1,columnspan=5,padx=10,pady=15)
textbox.config(bg="#cdc9c9")

#==============================Primera fila================================

#boton de elevar (**)
elevar=Button(ventana,text="**",width=5,command=lambda:click("**"))
elevar.grid(column=1,row=2)

#boton de modulo o obtener residuo de una division (%)
modulo=Button(ventana,text="%",width=5,command=lambda:click("%"))
modulo.grid(column=2,row=2)

#boton de division entera, el resultado al dividir sera siempre un numero entero (//)
div_entera=Button(ventana,text="//",width=5,command=lambda:click("//"))
div_entera.grid(column=3,row=2)

#boton de multiplicar (*)
multiplicar=Button(ventana,text="*",width=5,command=lambda:click("*"))
multiplicar.grid(column=4,row=2)

#boton de dividir (/)
div=Button(ventana,text="/",width=5,command=lambda:click("/"))
div.grid(column=5,row=2)
#=============================Segunda fila=================================
#boton del numero 7
siete=Button(ventana,text="7",width=5,bg="#898989",command=lambda:click(7))
siete.grid(column=1,row=3)

#boton del numero 8
ocho=Button(ventana,text="8",width=5,bg="#898989",command=lambda:click(8))
ocho.grid(column=2,row=3)

#boton del numero 9
nueve=Button(ventana,text="9",width=5,bg="#898989",command=lambda:click(9))
nueve.grid(column=3,row=3)

#boton de suma (-)
menos=Button(ventana,text="-",width=5,command=lambda:click("-"))
menos.grid(column=4,row=3)

#boton de resta (+)
mas=Button(ventana,text="+",width=5,command=lambda:click("+"))
mas.grid(column=5,row=3)
#============================Tercera fila===================================
#boton del numero 4
cuatro=Button(ventana,text="4",width=5,bg="#898989",command=lambda:click(4))
cuatro.grid(column=1,row=4)

#boton del numero 5
cinco=Button(ventana,text="5",width=5,bg="#898989",command=lambda:click(5))
cinco.grid(column=2,row=4)

#boton del numero 6
seis=Button(ventana,text="6",width=5,bg="#898989",command=lambda:click(6))
seis.grid(column=3,row=4)

#boton abrir parentesis
abrir_parentesis=Button(ventana,text="(",width=5,command=lambda:click("("))
abrir_parentesis.grid(column=4,row=4)

#boton cerrar parentesis
cerrar_parentesis=Button(ventana,text=")",width=5,command=lambda:click(")"))
cerrar_parentesis.grid(column=5,row=4)

#============================Cuarta fila===================================
#boton del numero 1
uno=Button(ventana,text="1",width=5,bg="#898989",command=lambda:click(1))
uno.grid(column=1,row=5)

#boton del numero 2
dos=Button(ventana,text="2",width=5,bg="#898989",command=lambda:click(2))
dos.grid(column=2,row=5)

#boton del numero 3
tres=Button(ventana,text="3",width=5,bg="#898989",command=lambda:click(3))
tres.grid(column=3,row=5)

#boton borrar un elemento
delete=Button(ventana,text="<=",width=5,bg="#ff7f50",command=eliminar)
delete.grid(column=4,row=5)

#boton Clear All (borrar todo)
Clear_all=Button(ventana,text="CA",width=5,bg="#ff7f50",command=clear_all)
Clear_all.grid(column=5,row=5)
#============================Quinta fila===================================

#boton de negativo
negativo=Button(ventana,text="neg",width=5)
negativo.grid(column=1,row=6)

#boton del numero 0
cero=Button(ventana,text="0",width=5,bg="#898989",command=lambda:click(0))
cero.grid(column=2,row=6)

#boton de punto, convierte un numero entero en decimal
punto=Button(ventana,text=".",width=5,command=lambda:click("."))
punto.grid(column=3,row=6)

#boton de resultado, al presionarlo da el resultado de la operacion
result=Button(ventana,text="=",width=12,bg="#cd5c5c",command=resultado)
result.grid(column=4,row=6,columnspan=2)
#=======================================================================

ventana.mainloop()
