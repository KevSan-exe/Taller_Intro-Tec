#1
#E:una lista y un valor
#S:una nueva lista con dos elementos, la suma de los elementos en [0:valor-1] y los siguientes
#R: el valor debe ser entero y tambien los elementos de la lista

def suma_elementos(lista,valor):
    if isinstance(lista,list) and isinstance(valor,int):
        if entero(lista):
            if valor>largo(lista):
                print("El valor es mayor a la longitud de la lista")
            else:
                x=suma_inicio(lista,valor,0,0)
                y=suma_final(lista[valor:],0)
                return [x,y]
        else:
            print("La lista solo puede estar conformado por numeros enteros")
    else:
        print("Debe ingresar una lista y un valor entero")

def suma_inicio(lista,valor,i,res):
    if i==valor:
        return res
    else:
        return suma_inicio(lista[1:],valor,i+1,lista[0]+res)

def suma_final(lista,res):
    if lista==[]:
        return res
    else:
        return suma_final(lista[1:],lista[0]+res)

def entero(lista):
    if lista==[]:
        return True
    else:
        if isinstance(lista[0],int):
            return entero(lista[1:])
        else:
            return False

##################################################################################
#2
#E:dos listas
#S:una lista formada por los valores de la primera que no se eencuentra en la segunda
#R:ambas listas pueden tener distinta longitud

def exclusion(lista1,lista2):
    if isinstance(lista1,list) and isinstance(lista2,list):
        return exclusion_aux(lista1,lista2,[])
    else:
        print("Ambos valores deben ser listas")

def exclusion_aux(lista1,lista2,res):
    if lista1==[]:
        return res
    else:
        if esta(lista1[0],lista2):
            return exclusion_aux(lista1[1:],lista2,res)
        else:
            return exclusion_aux(lista1[1:],lista2,res+[lista1[0]])

def esta(valor,lista):
    if lista==[]:
        return False
    else:
        if valor==lista[0]:
            return True
        else:
            return esta(valor,lista[1:])

##################################################################################
#3
#E:una lista
#S:una lista nueva formada por la cantidad de veces que se repite un digito en la misma posicion
#R:la lista puede ser de cualquier tamaNo

def frecuencias(lista):
    if isinstance(lista,list):
        return frecuencia_aux(lista,0,[])
    else:
        print("El valor debe ser una lista")

def frecuencia_aux(lista,pos,res):
    if pos>largo(lista)-1:
        return res
    else:
        x=veces(pos,lista,0)
        return frecuencia_aux(lista,pos+1,res+[x])

def veces(valor,lista,res):
    if lista==[]:
        return res
    else:
        if valor==lista[0]:
            return veces(valor,lista[1:],res+1)
        else:
            return veces(valor,lista[1:],res)

def largo(lista):
    return largo_aux(lista,0)

def largo_aux(lista,res):
    if lista==[]:
        return res
    else:
        return largo_aux(lista[1:],res+1)

##################################################################################
#4
#E:una matriz
#S:suma de los elementos en diagonal
#R:la matriz debe ser nxn (cuadrada)

def diagonal(m):
        if es_matriz(m):
            return diagonal_aux(m,0,0,0)
        else:
            print("Debe ingresar una matriz")

def diagonal_aux(m,i,pos,res):
    if m==[]:
        return res
    else:
        return diagonal_aux(m[1:],i+1,pos,res+m[pos][i])
        
def es_matriz(m):
    if m==[]:
        return True
    else:
        if isinstance(m[0],list):
            return es_matriz(m[1:])
        else:
            return False
        
##################################################################################
#5
#E:una lista
#S:una nueva lista que sin los digitos que se interponen para que la misma sea ordenada
#R:solo puede ingresar listas

def hacer_ordenada(lista):
    if isinstance(lista,list):
        if lista==[]:
            print("Lista vacia")
        else:
            return hacer_ordenada_aux(lista,[])
    else:
        print("Debe ingresar una lista")

def hacer_ordenada_aux(lista,res):
    if lista==[]:
        return res
    else:
        if largo(lista)==1:
            if lista[0]>res[largo(res)-1]:
                return hacer_ordenada_aux(lista[1:],res+[lista[0]])
            else:
                return hacer_ordenada_aux(lista[1:],res)
        else:
            if lista[0]<lista[1]:
                return hacer_ordenada_aux(lista[1:],res+[lista[0]])
            else:
                return hacer_ordenada_aux(lista[1:],res)

#I'm sorry
##################################################################################
#6
#E:una lista y una posicion
#S:el numero par en la posicion del valor
#R:si el no hay un numero par en dicha posicion se dira que no existe

def obtener_par(lista,pos):
    if isinstance(lista,list) and isinstance(pos,int) and pos>=0:
        if entero(lista):
            if lista==[]:
                print("Lista vacia")
            else:
                nuevo=hacer_lista(lista,[])
                par=par_lista(nuevo,pos-1)
                return par
        else:
            print("La lista solo puede estar conformada por numeros enteros")
    else:
        print("Debe ingresar una lista y un numero entero y positivo")

def hacer_lista(lista,res):
    if lista==[]:
        return res
    else:
        if lista[0]%2==0:
            return hacer_lista(lista[1:],res+[lista[0]])
        else:
            return hacer_lista(lista[1:],res)

def par_lista(lista,pos):
    if pos>largo(lista)-1:
        print("No existe")
    else:
        return lista[pos]
    
##################################################################################
#7
#E:una matriz
#S:una lista con el numero de las filas que sumadas dan un numero entero
#R:todos los datos deben ser enteros

def fila_primo(m):
    if es_matriz(m):
        return fila_primo_aux(m,0,[])
    else:
        print("Debe ingersar una matriz")

def fila_primo_aux(m,i,res):
    if m==[]:
        return res
    else:
        suma=suma_fila(m[0],0)
        if primo(suma):
            return fila_primo_aux(m[1:],i+1,res+[i])
        else:
            return fila_primo_aux(m[1:],i+1,res)

def suma_fila(lista,res):
    if lista==[]:
        return res
    else:
        return suma_fila(lista[1:],res+lista[0])
    
##################################################################################    
#9
#E:una lista y un elemento
#S:True si el elemento se encuentra en la mitad de la lista, False si no
#R:no se puede utilizar len()

def mitad(lista,valor):
    if isinstance(lista,list):
        if largo(lista)%2==0:
            return False
        else:
            return mitad_aux(lista,valor,largo(lista)-1)
    else:
        print("Debe ingresar una lista")

def mitad_aux(lista,valor,i):
    if valor==lista[i//2]:
        return True
    else:
        return False

##################################################################################
#10
#E:una lista y un valor "asc" o "desc"
#S:si es "asc" verificar si la lista es ascendente y si es "desc" verificar si es descendiente
#R:la lista solo puede tener numeros enteros

def sort_lista(lista,ad):
    if isinstance(lista,list):
        if entero(lista):
            if ad=="asc":
                return ascendente(lista,lista)
            elif ad=="desc":
                return descendente(lista,lista)
            else:
                print("Debe digitar una tarea a realizar validad")
        else:
            print("Error en los elementos de la lista")

def ascendente(lista,comp):
    if lista==[]:
        return True
    else:
        if largo(lista)==1:
            if lista[0]>comp[largo(comp)-2]:
                return True
            else:
                return False
        else:
            if lista[0]<lista[1]:
                return ascendente(lista[1:],comp)
            else:
                return False

def descendente(lista,comp):
    if lista==[]:
        return True
    else:
        if largo(lista)==1:
            if lista[0]<comp[largo(comp)-2]:
                return True
            else:
                return False
        else:
            if lista[0]>lista[1]:
                return descendente(lista[1:],comp)
            else:
                return False

##################################################################################
#14
#E:una matriz
#S:verificacion si la matriz es semi-magica(todas las sublistas sumadas dan lo mismo
#R:todas las sublistas deben ser del mismo tamaNo

def semi_magico(m):
    if isinstance(m,list) and es_matriz(m):
        if mismo_matriz(m,largo(m[0])):
            return semi_magico_aux(m,m[0],0)
        else:
            print("Sublistas de distintos tamaNos")
    else:
        print("Error de datos de entrada")

def semi_magico_aux(m,comp,i):
    if m==[]:
        return True
    else:
        if suma_lista(m[i])==suma_lista(comp):
            return semi_magico_aux(m[1:],comp,i+1)
        else:
            return False

def suma_lista(m):
    return suma_lista_aux(m,0)
def suma_lista_aux(m,res):
    if m==[]:
        return res
    else:
        return suma_lista_aux(m[1:],res+m[0])

def mismo_matriz(m,comp):
    if m==[]:
        return True
    else:
        if largo(m[0])==comp:
            return mismo_matriz(m[1:],comp)
        else:
            return False
##################################################################################
#15
#E:dos listas
#S:intercambio de los números de lista1 con los de lista2 cuando la suma de los números en una misma posición es un número primo
#R:ambas listas deben ser de la misma longitud

def intercambiar(lista1,lista2):
    if isinstance(lista1,list) and isinstance(lista2,list):
        if largo(lista1)==largo(lista2):
            return intercambiar_aux(lista1,lista2,[])
        else:
            print("Ambas listas deben tener la misma longitud")
    else:
        print("Ambos elementos deben ser listas")

def intercambiar_aux(lista1,lista2,res):
    if lista1==[]:
        return res
    else:
        if primo(lista1[0]+lista2[0]):
            return intercambiar_aux(lista1[1:],lista2[1:],res+[lista2[0]])
        else:
            return intercambiar_aux(lista1[1:],lista2[1:],res+[lista1[0]])

def primo(num):
    if num==0 or num==1:
        return False
    else:
        return primo_aux(num,2)

def primo_aux(num,div):
    if num==div:
        return True
    else:
        if num%div==0:
            return False
        else:
            return primo_aux(num,div+1)
##################################################################################
#20
#E:una lista y un numero
#S:indicar si el numero aparece en la lista y las posiciones en que aparece
#R:la lista puede ser heterogenea

def aparece_numero(lista,num):
    if isinstance(lista,list):
        x=veces_aparicion(lista,num,0,[])
        if esta(num,lista):
            print("Si aparece, en las posiciones:",x)
        else:
            print("No aparece")
    else:
        print("Debe ingresar una lista valida")

def veces_aparicion(lista,num,i,res):
    if lista==[]:
        return res
    else:
        if num==lista[0]:
            return veces_aparicion(lista[1:],num,i+1,res+[i])
        else:
            return veces_aparicion(lista[1:],num,i+1,res)




############################################################################################################################################################

def average(lista):
    if isinstance(lista,list) and entero(lista):
        x=suma_lista(lista,0)
        y=largo(lista)
        return x/y
    else:
        print("Error")

def suma_lista(lista,res):
    if lista==[]:
        return res
    else:
        return suma_lista(lista[1:],res+lista[0])

def entero(lista):
    if lista==[]:
        return True
    else:
        if isinstance(lista[0],int):
            return entero(lista[1:])
        else:
            return False
