#Tarea programada 1
#E:la solicitud al usuario para que ingrese el nombre del archivo y el tipo del mismo, ejemplo: archivo.txt 
#S:verificacion de la existencia del archivo y el retorno del nombre del mismo para su futura manipulacion
#R:si el archivo no existe se le indicara al usuario y se le solicitara que vuelva a ingresar un nombre del archivo 
def abrir_archivo():
    archivo=input("Ingrese el  nombre del documento y el tipo del mismo: ")
    ejecutar=open(archivo,"r")
    leer=ejecutar.read()
    ejecutar.close()
    return menu(archivo)

#E:el numero relacionado a la tarea que se desea elaborar
#S:la respuesta de la tarea que el usuario eligio
#R:si el usuario ingresa un valor que no corresponde a una de las tareas mostradas se le hara notar y se le pedira que lo vuelva a realizar 
def menu(archivo):
    print("Binevenido al la Clasificación mundial de universidades QS")
    print("1. Incluir")
    print("2. Mostrar top (ascendente)")
    print("3. Universidades por Segmento")
    print("4. Resumen")
    print("5. Salir")
    tarea=input("¿qué tarea desea realizar?: ")

#La opcion "Incluir" en el cual se le solicita al usuario los datos que desea ingresar al archivo
    if tarea=="1":
        pos=input("Ingrese una posicion o un ranking: ")
        nombre=input("Ingrese el nombre de la institucion: ")
        segmento=input("Ingrese el segmento de la institucion: ")
        zona=input("Ingrese la localizacion: ")
        rating=input("ingrese el rating de la institucion: ")
        variacion=input("Inrgese la variacion de la institucion: ")
        nuevo_archivo=open(archivo,"a")
        operacion=incluir(pos,nombre,segmento,zona,rating,variacion,nuevo_archivo)
        operacion
        return menu(archivo)

#La opcion "mostrar top (ascendente) en el cual se mostrar los datos del archivo de forma ascendente segun el ranking"
    elif tarea=="2":
        listatxt=open(archivo,"r")
        listaleer=listatxt.readlines()
        lista=crearlista(listaleer,[])
        operacion=ascendente(lista[1:],0,1)
        operacion
        return menu(archivo)

#La opcion "Universidades por segmento en donde el usuario podra observar las universidades que presenten el segmento que el  mismo ingrese"
    elif tarea=="3":
        info=input("Ingrese el segmento del cual desea informacion: ")
        listatxt=open(archivo,"r")
        listaleer=listatxt.readlines()
        lista=crearlista(listaleer,[])
        operacion=seg(lista[1:],0,info)
        operacion
        return menu(archivo)

    elif tarea=="4":
        listatxt=open(archivo,"r")
        listaleer=listatxt.readlines()
        lista=crearlista(listaleer,[])
        
        cant_universidades=largo(lista)-2
        rating_mayor=mayor(lista[1:],1,0)
        rating_menor=menor(lista[1:],1,0)
        
        print("la cantidad de universidades es", str(cant_universidades))
        print("mayor rating:",rating_mayor[0],"con rating",str(rating_mayor[1]))
        print("menor rating:",rating_menor[0],"con rating",str(rating_menor[1]))
        return menu(archivo)

    elif tarea=="5":
        print("Gracias por utilizar el programa")

    else:
        print("Ingrese un numero de tarea valida")
        return menu(archivo)

        
        
#######################################################################################################################################################################
#E:los datos que el usuario escribio para ser ingresados en el archivo
#S:la inclusion de estos datos en el archivo
#R:ciertos datos como posicion(ranking), rating y variacion deben ser numeros reales y positivos
def incluir(pos,nombre,segmento,zona,rating,variacion,archivo):
    archivo.write(pos)
    archivo.write(",")
    archivo.write(nombre)
    archivo.write(",")
    archivo.write(segmento)
    archivo.write(",")
    archivo.write(zona)
    archivo.write(",")
    archivo.write(rating)
    archivo.write(",")
    archivo.write(variacion)
    archivo.write("\n")
    archivo.close()
    print("Se incluyeron los datos correctamente")

#######################################################################################################################################################################
#E:los datos del archivo pero creado en lista
#S:la creacion de los datos del archivo en matriz para su manipulacion
#R:
def crearlista(lista,res):
    if lista==[]:
        return res
    else:
        caso=lista[0].rstrip()
        caso2=caso.split(",")
        res+=[caso2]
        return crearlista(lista[1:],res)
    
#######################################################################################################################################################################
#E:una matriz creada con los elementos del archivo, una posicion y un indice
#S:la muestra de los elementos de la matriz ordenadas de forma ascendente segun el ranking que presentan
#R:los rankings deben ser numeros enteros
def ascendente(lista,pos,ele):
    if largo(lista) == ele:
        print("")
    elif int(lista[pos][0])==ele:
        print(lista[pos][0]+","+lista[pos][1]+","+lista[pos][2]+","+lista[pos][3]+","+lista[pos][4]+","+lista[pos][5])
        pos=0
        return ascendente(lista,pos,ele+1)
    else:
        return ascendente(lista,pos+1,ele)
    
#######################################################################################################################################################################
#E:una matriz creada con los elementos del archivo, una posicion, un indice y un segmento que el usuario ingreso
#S:la informacion de las universidades con el segmento que el usuario ingreso
#R:si no se encuentra el segmento que el usuario ingreso no se podra mostrar ninguna informacion
def seg(lista,pos,info):
    if largo(lista) == pos:
        print("")
    else:
        if lista[pos][2]==info:
            print(lista[pos][0]+","+lista[pos][1]+","+lista[pos][2]+","+lista[pos][3]+","+lista[pos][4]+","+lista[pos][5])
            return seg(lista,pos+1,info)
        else:
            return seg(lista,pos+1,info)

#######################################################################################################################################################################
#E:una lista, una posicion y un indice
#S:el nombre con el rating mayor
#R:se debe trabajar con listas
def mayor(lista,pos,i):
    if largo(lista)==pos:
        return [lista[i][1],lista[i][4]]
    else:
        if float(lista[pos][4])>float(lista[i][4]):
            return mayor(lista,pos+1,pos)
        else:
            return mayor(lista,pos+1,i)

#######################################################################################################################################################################
#E:una lista, una posicion y un indice
#S:el nombre con el rating menor
#R:se debe trabajar con listas
def menor(lista,pos,i):
    if largo(lista)==pos:
        return [lista[i][1],lista[i][4]]
    else:
        if float(lista[pos][4])<float(lista[i][4]):
            return menor(lista,pos+1,pos)
        else:
            return menor(lista,pos+1,i)
#######################################################################################################################################################################
#E:una lista o matriz
#S:la cantidad de elementos que presenta
#R:el elemento que se ingrese debe ser una lista o matriz
def largo(lista):
    if lista==[]:
        return 0
    else:
        return 1+largo(lista[1:])


abrir_archivo()
