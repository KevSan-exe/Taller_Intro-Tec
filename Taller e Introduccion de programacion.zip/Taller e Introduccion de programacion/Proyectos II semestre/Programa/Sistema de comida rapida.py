#PROYECTO #1
#SISTEMA DE COMIDA RAPIDA
#################################################################################
#################################################################################
#Menu principal
#E: la solicitud del menu al que el usuario desea ingresar representada por indices
#S: redireccion al menu de opciones administrativas (1), el menu de opciones generales (2) o salir del programa (3)
#R; el usuario debe elegir la opcion por medio de los indices que presenta cada opcion de redireccion, si lo que el usuario ingresa no es valido se le hara saber y lo debera volver a ingresar
def menu_principal():
    print("______Bienvenido al menu principal______")
    print("1. Opciones Administrativas")
    print("2. Opciones Generales")
    print("3. Salir")

    tarea=input("Digite la tarea que desea realizar: ")
    if tarea=="1":
        return ingreso()
    elif tarea=="2":
        print("")
        return opciones_generales()
    elif tarea=="3":
        print("")
        print("Gracias por utilizar el programa")
    else:
        print("")
        print("La opcion que ingreso no es valida")
        print("")
        return menu_principal()
    
#################################################################################
#menu de ingreso por contrasena para poder entrar a las opciones administrativas
#E: la clave de ingreso (qwerty369)
#S: redireccion al menu de opciones administrativas
#R; si la clave que el usuario ingresa es incorrecta se le solicitara que intente nuevamente
def ingreso():
    clave="qwerty369"
    log_in=input("Ingrese la contraseña de ingreso: ")
    if clave==log_in:
        print("")
        return opciones_admin()
    else:
        print("")
        print("La contraseña que ingreso es incorrecta")
        print("")
        return ingreso()

#################################################################################
#Menu de opciones administrativas
#E: solicitud de la tarea de opciones administrativas por medio de un indice relacionado a la tarea a realizar
#R: redireccion a 1. Gestion de tipo de alimento, 2. Gestion de alimentos, 3. Gestion de combos, 4. Gestion de ordenes, 5. Facturar, 6. Consulta de facturacion, 7. Reporte de ventas o 8. Volver
#R: si la opcion que el usuario ingresa no es valida se le hara saber al usuario y se le pedira que ingrese algo valido
def opciones_admin():
    print("______Opciones Administrativas______")
    print("1. Gestion de tipo de alimento")
    print("2. Gestion de alimentos")
    print("3. Gestion de combos")
    print("4. Gestion de ordenes")
    print("5. Facturar")
    print("6. Consulta de facturacion")
    print("7. Reporte de ventas")
    print("8. Volver")

    tarea=input("Digite la tarea que desea realizar: ")
    if tarea=="1":
        print("")
        return tipo_alimento()
    elif tarea=="2":
        print("")
        return alimento()
    elif tarea=="3":
        print("")
        return combos()
    elif tarea=="4":
        print("")
        print("Esta opcion no esta disponible")
        print("")
        return opciones_admin()
    elif tarea=="5":
        print("")
        print("Esta opcion no esta disponible")
        print("")
        return opciones_admin()
    elif tarea=="6":
        print("")
        print("Esta opcion no esta disponible")
        print("")
        return opciones_admin()
    elif tarea=="7":
        print("")
        print("Esta opcion no esta disponible")
        print("")
        return opciones_admin()
    elif tarea=="8":
        print("")
        return menu_principal()
    else:
        print("")
        print("La opcion que ingreso no es valida")
        print("")
        return opciones_admin()

#################################################################################
#menu de gestion de tipo de alimento
#E: solicitud de la tarea de gestion de tipo de alimento por medio de un indice relacionado a la tarea a realizar
#S: redireccion a las tareas de 1. Incluir, 2. Eliminar, 3. Modificar, 4.Mostrar o 5. Volver segun se eliga
#R: si la opcion que el usuario ingresa no es valida se le hara saber y se le pedira que ingrese una opcion valida
def tipo_alimento():
    print("______Gestion de tipo de alimento______")
    print("1. Incluir")
    print("2. Eliminar")
    print("3. Modificar")
    print("4. Mostrar")
    print("5. Salir")

    tarea=input("Digite la tarea que desea realizar: ")
    if tarea=="1":
        print("")
        operacion=incluir_tipo_alimento()
        operacion
        print("")
        return tipo_alimento()    
    elif tarea=="2":
        print("")
        operacion=eliminar_tipo_alimento()
        operacion
        print("")
        return tipo_alimento()    
    elif tarea=="3":
        print("")
        operacion=modificar_tipo_alimento()
        operacion
        print("")
        return tipo_alimento()
    elif tarea=="4":
        print("")
        archivo="tipo_alimento.txt"
        texto="___Tipos de alimentos almacenados___"
        mostrar(archivo,texto)
        return tipo_alimento()
    elif tarea=="5":
        print("")
        return opciones_admin()
    else:
        print("")
        print("La opcion que ingreso no es valida")
        print("")
        return tipo_alimento()

#################################################################################
#funciones globales
#funciones las cuales se reutilizan en diversas funciones
#################################################################################
    
#funcion para mostrar los datos escritos en un archivo de texto que se desee observar
#El archivo y el titulo que se presentara entran a la funcion
def mostrar(archivo,texto):
    print(texto)
    doc=open(archivo,"r")
    archivo=doc.read()
    print(archivo)
    doc.close()

#funcion para crear la matriz del documento que se desee
#Entra una lista cualquiera con datos y una lista vacia en donde se creara la matriz
def crearMatriz(lista,res):
    if lista==[]:
        return res
    else:
        caso=lista[0].rstrip()
        caso2=caso.split(",")
        res+=[caso2]
        return crearMatriz(lista[1:],res)

#funcion para verificar si un dato que se ingreso existe en una matriz cualquiera
def esta(lista,descripcion):
    if lista==[]:
        return False
    else:
        if lista[0][0]==descripcion:
            return True
        else:
            return esta(lista[1:],descripcion)

#funcion para determinar el largo de una lista
def largo_lista(lista):
    if lista==[]:
        return 0
    else:
        return 1+largo_lista(lista[1:])

#funcion para determinar si existen dos tipos iguales en una lista modificada
#Entran una decripcion, una matriz y un indice en 0 que se le sumara 1 cada vez que encuentre la descripcion en la matriz
def seRepite(descripcion,lista,res):
    if res==2:
        return True
    elif lista==[]:
        return False
    else:
        if lista[0][0]==descripcion:
            res+=1
            return seRepite(descripcion,lista[1:],res)
        else:
            return seRepite(descripcion,lista[1:],res)

#funcion para mostrar los elementos de tipos de alimentos con indice comenzando en 1
def mostrar_indice(lista,i):
    if lista==[]:
        print("")
    else:
        print(str(i)+". ",lista[0][0])
        return mostrar_indice(lista[1:],i+1)

#funcion para eliminar de la matriz en base al archivo el alimento deseado
#entran un nombre una matriz una posicion en 0 y una valor False
#cuando se encuentre el nombre enla lista se eliminara y el False se convertira en True para determinar que la funcion debe parar
def eliminar(nombre,lista,pos,estado):
    if estado:
        return lista
    else:
        if (lista[pos][0]==nombre):
            lista=lista[0:pos]+lista[pos+1:]
            return eliminar(nombre,lista,pos,True)
        else:
            return eliminar(nombre,lista,pos+1,estado)

################################################################################# 
#################################################################################    
#funcion para incluir un tipo de alimento
#E: los datos que se le solicitan al usuario son descripcion del tipo, origen del tipo y verificar si el alimento presenta o no presenta gluten
#S: los datos ingresados guardados en el archivo de texto de tipo de alimento
#R: cuando se verifique si el tipo presenta gluten se debe hacer unicamento con si o no, no pueden existir dos tipos de alimento iguales
def incluir_tipo_alimento():
    archivo="tipo_alimento.txt"
    texto="___Tipos de alimentos almacenados___"
    mostrar(archivo,texto)
    print("___Incluir tipo de alimento___")
    descripcion=input("Ingrese la descripcion del tipo: ")
    origen=input("Ingrese el origen: ")
    gluten=input("Ingrese si es libre de gluten (si o no): ")

    archivo=open("tipo_alimento.txt","r")
    listatxt=archivo.readlines()
    lista=crearMatriz(listatxt,[])
    if esta(lista,descripcion):
        print("")
        print("No pueden existir dos tipos de alimentos con la misma descripcion")
    else:
        if gluten=="no" or gluten=="si":
            archivo.close()
            return escribir_tipoAlimento(descripcion,origen,gluten)
        else:
            print("")
            print("Debe definir si el producto contiene gluten con si o no")

#funcion para escribir los datos de tipo de alimento en el archivo
#E: la descripcion, el origen y estado de gluten que el usuario ingreso
#S: la adicion de los datos en el archivo
#R: solo se puede acceder a esta funcion si el tipo de alimento no esta repetido y se determino los datos de gluten con si o no 
def escribir_tipoAlimento(descripcion,origen,gluten):
    archivo=open("tipo_alimento.txt","a")
    archivo.write(descripcion)
    archivo.write(",")
    archivo.write(origen)
    archivo.write(",")
    archivo.write(gluten)
    archivo.write("\n")
    archivo.close()
    print("")
    print("Se guardaron los datos con exito")

#################################################################################  
#funcion para eliminar un tipo de alimento
#E: la descripcion del tipo de alimento que el usuario desea eliminar'
#S: la actualizacion del archivo de tipos de alimentos sin el tipo que el usuario desea eliminar
#R: no se puede eliminar un tipo de alimento asociado a un alimento, no se podra eliminar un tipo que no exista
def eliminar_tipo_alimento():
    archivo="tipo_alimento.txt"
    texto="___Tipos de alimentos almacenados___"
    mostrar(archivo,texto)
    print("___Eliminar tipo de alimento___")
    descripcion=input("Ingrese la descripcion del tipo que desea eliminar: ")

    archivo=open("tipo_alimento.txt","r")
    listatxt=archivo.readlines()
    lista=crearMatriz(listatxt,[])
    archivo.close()

    if esta(lista,descripcion):
        nueva_lista=eliminar_tipo(descripcion,lista,0,False)
        archivo2=open("tipo_alimento.txt","w")
        eliminar_tipo_alimentoAux(nueva_lista,archivo2)
        print("")
        print("Se eliminaron los datos correctamente")
    else:
        print("")
        print("El tipo de alimento que desea eliminar no existe")

#funcion eliminar el tipo de alimento de la lista creada a partir de el archivo donde se almacena los tipos de alimento
#E: la descripcion del tipo, la matriz creada a partir del archivo, una posicion que comienza en 0 y un valor booleano False
#S: la lista del archivo con el tipo deseado eliminado
#R: si la matriz en la posicion indicada no es igual al tipo se le sumara 1 a la posicion hasta encontrarlo
def eliminar_tipo(descripcion,lista,pos,estado):
    if estado:
        return lista
    else:
        if (lista[pos][0]==descripcion):
            lista=lista[0:pos]+lista[pos+1:]
            return eliminar_tipo(descripcion,lista,pos,True)
        else:
            return eliminar_tipo(descripcion,lista,pos+1,estado)

#funcion para actualizar el archivo con el tipo deseado finalmente eliminado
#E: la matriz sin el tipo que se deseaba eliminar y el archivo de tipo de alimento listo para actualizar
#S: el archivo con los datos actualizados
#R: el archivo entra a la funcion abierto y se cierra una vez todos los datos se hayan ingresado al archivo
def eliminar_tipo_alimentoAux(lista,archivo):
    if lista==[]:
        archivo.close()
    else:
        archivo.write(lista[0][0]+","+lista[0][1]+","+lista[0][2])
        archivo.write("\n")
        return eliminar_tipo_alimentoAux(lista[1:],archivo)

#################################################################################  
#funcion para modificar un tipo de alimento
#E: la descripcion del tipo de alimento que el usuario desea eliminar y los datos que se usaran para realizar la modificacion
#S: la actualizacion del archivo de tipos de alimentos con el tipo modificado con los datos deseados
#R: se debe volver a determinar si el tipo presenta gluten con si o no, no pueden existir dos datos con la misma descripcion, no se puede modificar un tipo que no exista
def modificar_tipo_alimento():
    archivo="tipo_alimento.txt"
    texto="___Tipos de alimentos almacenados___"
    mostrar(archivo,texto)
    print("___Modificar tipo de alimento___")
    descripcion=input("Ingrese la descripcion del tipo que desea modificar: ")

    archivo=open("tipo_alimento.txt","r")
    listatxt=archivo.readlines()
    lista=crearMatriz(listatxt,[])
    archivo.close()

    if esta(lista,descripcion):
        print("")
        nueva_descripcion=input("Ingrese la nueva descripcion del tipo: ")
        nuevo_origen=input("Ingrese el origen: ")
        nuevo_gluten=input("Ingrese si es libre de gluten (si o no): ")
        modi=lista_modificada_tipo(lista,descripcion,nueva_descripcion,nuevo_origen,nuevo_gluten,[])
        if seRepite(nueva_descripcion,modi,0):
            print("")
            print("No pueden existir dos tipos de alimento iguales")
        else:
            if nuevo_gluten=="si" or nuevo_gluten=="no":
                archivo_modificar=open("tipo_alimento.txt","w")
                modificar_archivo_tipo(modi,archivo_modificar)
                print("")
                print("Se modificaron los datos correctamente")
            else:
                print("")
                print("Determine si el alimento presenta gluten con si o no")
    else:
        print("")
        print("El tipo de alimento que desea modificar no existe")

#funcion para modificar el tipo de alimento con los datos de modificacion en la matriz creada con los datos del archivo
#E: una matriz creada a partir del archivo de texto, el tipo que se desea modificar, la informacion para modificar y una lista vacia
#S: una nueva lista con el tipo deseado con su informacion modificada
#R: la nueva lista se otorgara una vez la matriz a base del archivo de texto este vacia
def lista_modificada_tipo(lista,descripcion,nueva_descripcion,nuevo_origen,nuevo_gluten,res):
    if lista==[]:
        return res
    else:
        if lista[0][0]==descripcion:
            res+=[[nueva_descripcion,nuevo_origen,nuevo_gluten]]
            return lista_modificada_tipo(lista[1:],descripcion,nueva_descripcion,nuevo_origen,nuevo_gluten,res)
        else:
            res+=[[lista[0][0],lista[0][1],lista[0][2]]]
            return lista_modificada_tipo(lista[1:],descripcion,nueva_descripcion,nuevo_origen,nuevo_gluten,res)

#funcion para guardar la informacion de la matriz con el tipo modificado  en el archivo de texto
#E: una matriz con los deseado modificado y el archivo de texto de los tipos de alimentos listo para escribir
#S: el archivo con los datos actualizado
#R: el archivo se cierra una vez la matriz este vacia
def modificar_archivo_tipo(lista,archivo):
    if lista==[]:
        return archivo.close()
    else:
        archivo.write(lista[0][0]+","+lista[0][1]+","+lista[0][2])
        archivo.write("\n")
        return modificar_archivo_tipo(lista[1:],archivo)

#################################################################################
#################################################################################
#menu de gestion de alimento
#E: solicitud de la tarea de gestion de alimento por medio de un indice relacionado a la tarea a realizar
#S:  redireccion a las tareas de 1. Incluir, 2. Eliminar, 3. Modificar, 4.Mostrar o 5. Volver segun se eliga
#R: si la opcion que el usuario ingresa no es valida se le hara saber y se le pedira que ingrese una opcion valida
def alimento():
    print("______Gestion de alimentos______")
    print("1. Incluir")
    print("2. Eliminar")
    print("3. Modificar")
    print("4. Mostrar")
    print("5. Salir")

    tarea=input("Digite la tarea que desea realizar: ")
    if tarea=="1":
        print("")
        operacion=incluir_alimento()
        operacion
        print("")
        return alimento()    
    elif tarea=="2":
        print("")
        operacion=eliminar_alimento()
        operacion
        print("")
        return alimento()    
    elif tarea=="3":
        print("")
        operacion=modificar_alimento()
        operacion
        print("")
        return alimento()
    elif tarea=="4":
        print("")
        archivo="alimento.txt"
        texto="___Alimentos almacenados___"
        mostrar(archivo,texto)
        return alimento()
    elif tarea=="5":
        print("")
        return opciones_admin()
    else:
        print("")
        print("La opcion que ingreso no es valida")
        print("")
        return alimento()
    
#################################################################################    
#funcion para incluir un alimento a el archivo de texto de alimentos
#E: los datos que se le solicitan al usuario son nombre, el indice del tipo de alimento, el costo de compra, margen de ganancia y precio de venta (se calcula automaticamente)
#S: la adicion de estos datos al archivo de texto
#R: no pueden existir dos alimentos con el mismo nombre, el tipo de alimento se debe seeccionar po medio de un indice, costo de compra debe ser un entero, margen debe ser entre 1 y 100
def incluir_alimento():
    archivo_tipo=open("tipo_alimento.txt","r")
    listatxt_tipo=archivo_tipo.readlines()
    lista_tipo=crearMatriz(listatxt_tipo,[])
#######################
    archivo=open("alimento.txt","r")
    listatxt=archivo.readlines()
    lista=crearMatriz(listatxt,[])

    archivo="alimento.txt"
    texto="___Alimentos almacenados___"    
    mostrar(archivo,texto)
    
    print("___Incluir alimento___")
    nombre=input("Ingrese el nombre del alimento: ")
    print("")
    print("___Tipos de alimento___")
    mostrar_indice(lista_tipo,1)
    tipo=input("Ingrese el indice del tipo de alimento que desea agregar: ")
    costo_compra=input("Ingrese el costo de compra: ")
    margen=input("Ingrese el margen de ganancia: ")

    if es_entero(tipo) and es_entero(costo_compra) and es_entero(margen):
        tipo=int(tipo)
        costo_compra=int(costo_compra)
        margen=int(margen)
        if (tipo>0) and (tipo<=largo_lista(lista_tipo)):
            if (costo_compra>0):
                if (margen>0 and margen<=100):
                    if esta(lista,nombre):
                        print("")
                        print("No pueden existir dos alimentos iguales")
                    else:
                        venta=costo_compra+(margen/0.1)
                        archivo_incluir=open("alimento.txt","a")
                        return incluir_alimento_aux(archivo_incluir,nombre,lista_tipo[tipo-1][0],costo_compra,margen,venta)
                else:
                    print("")
                    print("El margen de ganancia debe ser un entero entre 0 y 100")
            else:
                print("")
                print("El costo de compra debe ser un numero entero positivo")   
        else:
            print("")
            print("El tipo de alimento debe ser representado por uno de los numeros adjunto al tipo de alimento que se presentan")
    else:
        print("")
        print("El indice relacionado al tipo de alimento, el costo de compra y el margen de ganancia deben ser numeros enteros")

#funcion para guardar los datos ingresados por el usuario
#E: el archivo donde se almacenan los alimentos, nombre, descripcion del tipo de alimento, costo de compra, margen de ganancia y precio de venta
#S: los datos agregados al archivo de texto
#R: el archivo se cierra una vez losdatos sean ingresados al archivo
def incluir_alimento_aux(archivo,nombre,tipo,costo_compra,margen,venta):
    archivo.write(nombre)
    archivo.write(",")
    archivo.write(tipo)
    archivo.write(",")
    archivo.write(str(costo_compra))
    archivo.write(",")
    archivo.write(str(margen))
    archivo.write(",")
    archivo.write(str(int(venta)))
    archivo.write("\n")
    archivo.close()
    print("")
    print("Se guardaron los datos con exito")
            
##################################################################################                        
#funcion para eliminar un alimento deseado del archivo
#E: el nombre del alimento que se desea eliminar
#S: el archivo actualizado con el alimento deseado eliminado
#R: no se puede eliminar un alimento asociado a una factura, combo o orden,no se puede eliminar un alimento que no existe
def eliminar_alimento():
    archivo="alimento.txt"
    texto="___Alimentos almacenados___"  
    mostrar(archivo,texto)
    print("___Eliminar alimento___")
    nombre=input("Ingrese el nombre del alimento que desea eliminar: ")

    archivo=open("alimento.txt","r")
    listatxt=archivo.readlines()
    lista=crearMatriz(listatxt,[])
    archivo.close()

    if esta(lista,nombre):
        nueva_lista=eliminar(nombre,lista,0,False)
        archivo2=open("alimento.txt","w")
        eliminar_alimentoAux(nueva_lista,archivo2)
        print("")
        print("Se eliminaron los datos correctamente")
    else:
        print("")
        print("El alimento que desea eliminar no existe")

#funcion para actualizar la lista con alimento ya eliminado
#E: la matriz actualizada y un archivo abierto
#S: el archivo de texto actualizado
#R: el archivo se cierra una vez todos los elementos se hayan ingresado
def eliminar_alimentoAux(lista,archivo):
    if lista==[]:
        archivo.close()
    else:
        archivo.write(lista[0][0]+","+lista[0][1]+","+lista[0][2]+","+lista[0][3]+","+lista[0][4])
        archivo.write("\n")
        return eliminar_alimentoAux(lista[1:],archivo)
    
##################################################################################    
#funcion para modificar un alimento
#E: el nombre del alimento que se desea modificar y la informacion que se utilizara para la modificacion
#S: la lista actualizada con la actualizacion
#R: las mismas que incluir
def modificar_alimento():
    archivo="alimento.txt"
    texto="___Alimentos almacenados___"  
    mostrar(archivo,texto)
    print("___Modificar alimento___")
    nombre=input("Ingrese el nombre del alimento que desea modificar: ")

    archivo=open("alimento.txt","r")
    listatxt=archivo.readlines()
    lista=crearMatriz(listatxt,[])
    archivo.close()

####################
    archivo_tipo=open("tipo_alimento.txt","r")
    listatxt_tipo=archivo_tipo.readlines()
    lista_tipo=crearMatriz(listatxt_tipo,[])
####################
    
    if esta(lista,nombre):
        print("")
        nuevo_nombre=input("Ingrese el nuevo nombre del alimento: ")
        print("")
        print("___Tipos de alimento___")
        mostrar_indice(lista_tipo,1)
        nuevo_tipo=input("Ingrese el nuevo indice del tipo de alimento que desea agregar: ")
        nuevo_costo_compra=input("Ingrese el nuevo costo de compra: ")
        nuevo_margen=input("Ingrese el nuevo margen de ganancia: ")
        
        if es_entero(nuevo_tipo) and es_entero(nuevo_costo_compra) and es_entero(nuevo_margen):
            nuevo_tipo=int(nuevo_tipo)
            nuevo_costo_compra=int(nuevo_costo_compra)
            nuevo_margen=int(nuevo_margen)
            if (nuevo_tipo>0) and (nuevo_tipo<=largo_lista(lista_tipo)):
                if (nuevo_costo_compra>0):
                    if (nuevo_margen>0 and nuevo_margen<=100):
                        nuevo_venta=nuevo_costo_compra+(nuevo_margen/0.1)
                        lista_modificada=modificar_archivo_alimento(nombre,lista,nuevo_nombre,lista_tipo[nuevo_tipo-1][0],str(nuevo_costo_compra),str(nuevo_margen),str(nuevo_venta),[])
                        if seRepite(nuevo_nombre,lista_modificada,0):
                            print("")
                            print("No pueden existir dos alimentos iguales")
                        else:
                            archivo2=open("alimento.txt","w")
                            modificar_alimento_aux(archivo2,lista_modificada)
                            print("")
                            print("Se modificaron los datos correctamente")
                    else:
                        print("")
                        print("El margen de ganancia debe ser un numero entero entre 0 y 100")
                else:
                    print("")
                    print("El costo de compra debe ser un numero entero y positivo")   
            else:
                print("")
                print("El tipo de alimento debe ser representado por uno de los numeros adjunto al tipo de alimento que se presentan")
        else:
            print("")
            print("El indice relacionado al tipo de alimento, el costo de compra y el margen de ganancia deben ser numeros enteros")
    else:
        print("")
        print("El tipo de alimento que desea modificar no existe")


#funcion para modificar un alimento en la lista con los datos de alimentos con los que se ingresaron
#se ingresa un nombre, la matriz con los datos, los datos de modificacion y una lista vacia
#la lista vacia se llenara con los datos originales pero cuando se encuentre el dato que se desea modificar se ingresaran los datos de modificacion 
def modificar_archivo_alimento(nombre,lista,nuevo_nombre,nuevo_tipo,nuevo_costo_compra,nuevo_margen,nuevo_venta,res):
    if lista==[]:
        return res
    else:
        if lista[0][0]==nombre:
            res+=[[nuevo_nombre,nuevo_tipo,nuevo_costo_compra,nuevo_margen,nuevo_venta]]
            return modificar_archivo_alimento(nombre,lista[1:],nuevo_nombre,nuevo_tipo,nuevo_costo_compra,nuevo_margen,nuevo_venta,res)
        else:
            res+=[[lista[0][0],lista[0][1],lista[0][2],lista[0][3],lista[0][4]]]
            return modificar_archivo_alimento(nombre,lista[1:],nuevo_nombre,nuevo_tipo,nuevo_costo_compra,nuevo_margen,nuevo_venta,res)

#funcion para guardar los datos de alimento despues de realizar la modificacion
def modificar_alimento_aux(archivo,lista):
    if lista==[]:
        return archivo.close()
    else:
        archivo.write(lista[0][0]+","+lista[0][1]+","+lista[0][2]+","+lista[0][3]+","+lista[0][4])
        archivo.write("\n")
        return modificar_alimento_aux(archivo,lista[1:])
            
##################################################################################                        
#menu de gestion de combos
#E: solicitud de la tarea de gestion de combos por medio de un indice relacionado a la tarea a realizar
#S:  redireccion a las tareas de 1. Incluir, 2. Eliminar, 3. Modificar, 4.Mostrar o 5. Volver segun se eliga
#R: si la opcion que el usuario ingresa no es valida se le hara saber y se le pedira que ingrese una opcion valida
def combos():
    print("______Gestion de combos______")
    print("1. Incluir")
    print("2. Eliminar")
    print("3. Modificar")
    print("4. Mostrar")
    print("5. Salir")

    tarea=input("Digite la tarea que desea realizar: ")
    if tarea=="1":
        print("")
        operacion=incluir_combo()
        operacion
        print("")
        return combos()    
    elif tarea=="2":
        print("")
        operacion=eliminar_combo()
        operacion
        print("")
        return combos()    
    elif tarea=="3":
        print("")
        operacion=modificar_combo()
        operacion
        print("")
        return combos()
    elif tarea=="4":
        print("")
        archivo="combos.txt"
        texto="___Alimentos almacenados___"
        mostrar(archivo,texto)
        return combos()
    elif tarea=="5":
        print("")
        return opciones_admin()
    else:
        print("")
        print("La opcion que ingreso no es valida")
        print("")
        return combos()
    
##################################################################################                        
#funcion para incluir un combo al archivo
#E: un nombre para el combo, un costo, un margen, un precio de venta, alimentos y la cantidad que llevara el combo (se debera seleccionar por medio de un indice)
#S: la informacion ingresada escrita en el archivo de texto
#R: se debe poder incluir y eliminar alimentos
def incluir_combo():
    archivo=open("combos.txt","r")
    listatxt=archivo.readlines()
    matriz=crearMatriz(listatxt,[])

    archivo="combos.txt"
    texto="___Combos almacenados___"   
    mostrar(archivo,texto)
    
    nombre=input("Ingrese el nombre del combo: ")
    costo=input("Ingrese el costo: ")
    margen=input("Ingrese un margen: ")

    if esta(matriz,nombre):
        print("")
        print("No pueden existir dos combos iguales")
    else:
        if es_entero(costo) and es_entero(margen):
            costo=int(costo)
            margen=int(margen)
            if costo>0:
                if 0<margen<=100:
                    precio_venta=costo+(margen/0.1)
                    print("")
                    return incluir_combo_aux(nombre,costo,margen,precio_venta,[])
                else:
                    print("")
                    print("El margen debe ser un numero entero entre 0 y 100")
            else:
                print("El costo debe ser un numero entero y positivo")
        else:
            print("")
            print("La informacion que se ingresa en costo y margen debe ser un valor entero")

#funcion para finalizar la inclusion de combos
#E: el nombre del compo, el costo, el margen, el precio de venta y una lista vacia donde iran los alimentos que llevara el combo
#S: dependiendo de la opcion que eliga el usuario se podra: 1. ingresar un alimento alcombo, 2. eliminar un alimento del combo, 3. mostrar los alimentos que estan listos para ser incluidos al combo o finalizar y guardar los datos
#R: los alimentos se mostraran y seleccionara junto a un indice que los representa y se debera indicar las cantidades que el combo llevara de dicho alimento
def incluir_combo_aux(nombre,costo,margen,precio_venta,ali):
    archivo_ali=open("alimento.txt","r")
    listatxt_ali=archivo_ali.readlines()
    matriz_ali=crearMatriz(listatxt_ali,[])

    print("___Conclusion de la inclucion___")
    print("1. Ingresar un alimento")
    print("2. Eliminar un alimento")
    print("3. Mostrar los alimentos incluidos")
    print("4. Finalizar la inclusion")

    tarea=input("Ingrese la tarea que desea realizar: ")

    if tarea=="1":
        print("")
        print("___Alimentos almacenados___")
        mostrar_alimento_indice(matriz_ali,1)
        i=input("Ingrese el indice del alimento que desea incluir al combo: ")
        cant=input("Ingrese la cantidad que desea agregar: ")
        if (es_entero(i) and es_entero(cant)):
            i=int(i)
            cant=int(cant)
            if (i<=largo_lista(matriz_ali) and i>0) and cant>0:
                if esta(ali,matriz_ali[i-1][0]):
                    ali=sumar_ali_combo(matriz_ali[i-1][0],ali,cant,[])
                    print("")
                    print("Se adicionaron los alimentos con exito")
                    print("")
                    return incluir_combo_aux(nombre,costo,margen,precio_venta,ali)
                else:
                    ali+=[[matriz_ali[i-1][0],cant]]
                    print("")
                    print("Se agregaron los alimentos con exito")
                    print("")
                    return incluir_combo_aux(nombre,costo,margen,precio_venta,ali)
            else:
                print("")
                print("El alimento se debe seleccionar segun el indice que lo representa y las cantidades deben ser positivas y enteras")
        else:
            print("")
            print("El alimento se debe seleccionar segun el indice que lo representa y las cantidades deben ser positivas y enteras")
            
    elif tarea=="2":
        print("")
        print("___Alimentos listos para incluir___")
        mostrar_ali_incluido(ali,1)
        i=input("Ingrese el indice del alimento que desea eliminar de la inclucion: ")
        cant=input("Ingrese la cantidad que desea eliminar: ")
        if es_entero(i) and es_entero(cant):
            i=int(i)
            cant=int(cant)
            if (i<=largo_lista(ali) and i>0) and cant>0:
                ali=restar_ali_combo(ali[i-1],ali,cant,[])
                print("")
                print("Se elimino correctamente")
                print("")
                return incluir_combo_aux(nombre,costo,margen,precio_venta,ali)
            else:
                print("")
                print("El alimento se debe seleccionar segun el indice que lo representa y la debe ser un numero entero y positivo")
        else:
            print("")
            print("El alimento se debe seleccionar segun el indice que lo representa y la cantidad debe ser un numero entero y positivo")
            
    elif tarea=="3":
        print("")
        print("___Alimentos listos para incluir___")
        mostrar_ali_incluido(ali,1)
        return incluir_combo_aux(nombre,costo,margen,precio_venta,ali)
    
    elif tarea=="4":
        if ali==[]:
            print("")
            print("no puede finalizar con la inclusion porque no hay ingresado un alimento")
        else:
            ali=convertir_lista_ali(ali,[])
            incluir_combo_texto(nombre,costo,margen,precio_venta,ali)
            print("")
            print("Se incluyo el combo con exito")
    else:
        print("")
        print("La opcion que ingreso no es valida")
        print("")
        return incluir_combo_aux(nombre,costo,margen,precio_venta,ali)

#funcion para convertir una matriz a lista con los datos de alimentos que iran a los acombos
#entran la matriz con los alimentos de un combo y una lista vacia
def convertir_lista_ali(ali,res):
    if ali==[]:
        return res
    else:
        res+=[ali[0][0],ali[0][1]]
        return convertir_lista_ali(ali[1:],res)

#funcion para incluir los datos de los alimentos de los combos al archivo de texto
def incluir_combo_ali(ali,archivo):
    if ali==[]:
        archivo.write("\n")
        archivo.close()
    else:
        archivo.write(",")
        archivo.write(ali[0])
        archivo.write(",")
        archivo.write(str(ali[1]))
        return incluir_combo_ali(ali[2:],archivo)
    
#funcion para finalizar la inclusion de un combo
#E: el nombre del combo, el costo ingresado, el margen de ganancia, el precio de venta y los alimentos ingresados 
#S: la informcacion del combo agregada al arhcivo de combos
#R: el archivo se cierra una vez los 
def incluir_combo_texto(nombre,costo,margen,precio_venta,ali):
    archivo=open("combos.txt","a")
    archivo.write(nombre)
    archivo.write(",")
    archivo.write(str(costo))
    archivo.write(",")
    archivo.write(str(margen))
    archivo.write(",")
    archivo.write(str(precio_venta))
    incluir_combo_ali(ali,archivo)

#funcion para mostrar los alimentos para incluir en un combo con indices, comenzando desde 0
#entran un matriz con los alimentos y un indice en 1
def mostrar_ali_incluido(ali,i):
    if ali==[]:
        print("")
    else:
        print(str(i)+".",str(ali[0][0])+","+str(ali[0][1]))
        return mostrar_ali_incluido(ali[1:],i+1)

#funcion para sumar las cantidades que se le adjuntan a un alimento que se incluira a un combo
#cuando se encuentra el alimento que se busca para sumar las cantidades estas se suman estas pero el resto de los alimentos quedan igual
def sumar_ali_combo(elemento,ali,cant,res):
    if ali==[]:
        return res
    else:
        if ali[0][0]==elemento:
            nueva_cant=(ali[0][1])+cant
            res+=[[ali[0][0],nueva_cant]]
            return sumar_ali_combo(elemento,ali[1:],cant,res)
        else:
            res+=[[ali[0][0],ali[0][1]]]
            return sumar_ali_combo(elemento,ali[1:],cant,res)

#funcion para restar las cantidades que se le adjuntan a un alimento que se incluira a un combo
#si las resta de unas cantidades dan como resultado menor o igual a 0 el alimento se elimina de la inclusion 
def restar_ali_combo(elemento,ali,cant,res):
    if ali==[]:
        return res
    else:
        if elemento==ali[0]:
            nueva_cant=ali[0][1]-cant
            if nueva_cant>0:
                res+=[[ali[0][0],nueva_cant]]
                return restar_ali_combo(elemento,ali[1:],cant,res)
            else:
                return restar_ali_combo(elemento,ali[1:],cant,res)
        else:
            res+=[[ali[0][0],ali[0][1]]]
            return restar_ali_combo(elemento,ali[1:],cant,res)

##################################################################
#funcion para eliminar un combo del archivo
#se solicita que ingrese el nombre del combo que desea eliminar si este existe se continua con la operacion por el contrario se le notara al usuario que su opcion es invalida 
def eliminar_combo():
    archivo=open("combos.txt","r")
    listatxt=archivo.readlines()
    matriz=crearMatriz(listatxt,[])

    archivo="combos.txt"
    texto="___Combos almacenados___"   
    mostrar(archivo,texto)

    print("___Eliminar combo___")
    nombre=input("Ingrese el nombre del combo que desea eliminar: ")

    if esta(matriz,nombre):
        nueva_lista=eliminar(nombre,matriz,0,False)
        archivo2=open("combos.txt","w")
        eliminar_comboAux(nueva_lista,archivo2)
        print("")
        print("Se eliminaron los datos correctamente")
    else:
        print("")
        print("El acombo que desea eliminar no existe")

#funcion para finalizar la eliminacion de un combo deseado del archivo de combos
def eliminar_comboAux(lista,archivo):
    if lista==[]:
        archivo.close()
    else:
        archivo.write(lista[0][0]+","+lista[0][1]+","+lista[0][2]+","+lista[0][3])
        neo_lista=lista[0]
        eliminar_comboAux_ali(archivo,neo_lista[4:])
        return eliminar_comboAux(lista[1:],archivo)

#funcion para terminar la eliminacion de un combo del archivo donde se almacenan
#esta funcion se encarga unicamente de los alimentos adjuntos al texto
def eliminar_comboAux_ali(archivo,lista):
    if lista==[]:
        archivo.write("\n")
    else:
        archivo.write(",")
        archivo.write(str(lista[0]))
        archivo.write(",")
        archivo.write(str(lista[1]))
        return eliminar_comboAux_ali(archivo,lista[2:])
    
##################################################################################
#funcion para realizar la modificacion  de un combo del archivo donde se almacenan
#si el combo que el usuario desea modificar no existe se le hara saber al usuario
#el usuario debera ingresar la nuevo informacion para realizar la modificacion
def modificar_combo():
    archivo=open("combos.txt","r")
    listatxt=archivo.readlines()
    matriz=crearMatriz(listatxt,[])

    archivo="combos.txt"
    texto="___Combos almacenados___"   
    mostrar(archivo,texto)
    
    print("___Modificar combo___")
    nombre=input("Ingrese el nombre del combo que desea modificar: ")

    if esta(matriz,nombre):
        nuevo_nombre=input("Ingrese el nuevo nombre del combo: ")
        nuevo_costo=input("Ingrese nuevo el costo: ")
        nuevo_margen=input("Ingrese el nuevo margen: ")
        if es_entero(nuevo_costo) and es_entero(nuevo_margen):
            nuevo_costo=int(nuevo_costo)
            nuevo_margen=int(nuevo_margen)
            if nuevo_costo>0:
                if 0<nuevo_margen<=100:
                    precio_venta=nuevo_costo+(nuevo_margen/0.1)
                    print("")
                    return modificar_combo_aux(nombre,nuevo_nombre,nuevo_costo,nuevo_margen,precio_venta,[])
                else:
                    print("")
                    print("El margen debe ser un numero entero entre 0 y 100")
            else:
                print("")
                print("El costo debe ser un numero entero y positivo")
        else:
            print("")
            print("El costo y el margen deben ser datos enteros y positivos")
    else:
        print("")
        print("El combo que desea modificar no existe")

#funcion para incluir los alimentos que el usuario desee al combo que desea modificar
#los alimentos y las cantidades se guardaran en un lista
#se podra sumar y restar cantidades de los alimentos que se desean incluir al combo
def modificar_combo_aux(nombre,nuevo_nombre,nuevo_costo,nuevo_margen,precio_venta,ali):
    archivo_ali=open("alimento.txt","r")
    listatxt_ali=archivo_ali.readlines()
    matriz_ali=crearMatriz(listatxt_ali,[])

    print("___Conclusion de la modificacion___")
    print("1. Ingresar un alimento")
    print("2. Eliminar un alimento")
    print("3. Mostrar los alimentos incluidos")
    print("4. Finalizar la inclusion")
    
    tarea=input("Ingrese la tarea que desea realizar: ")

    if tarea=="1":
        print("")
        print("___Alimentos almacenados___")
        mostrar_alimento_indice(matriz_ali,1)
        i=input("Ingrese el indice del alimento que desea incluir al combo: ")
        cant=input("Ingrese la cantidad que desea agregar: ")
        if (es_entero(i) and es_entero(cant)):
            i=int(i)
            cant=int(cant)
            if (i<=largo_lista(matriz_ali) and i>0) and cant>0:
                if esta(ali,matriz_ali[i-1][0]):
                    ali=sumar_ali_combo(matriz_ali[i-1][0],ali,cant,[])
                    print("")
                    print("Se adicionaron los alimentos con exito")
                    print("")
                    return modificar_combo_aux(nombre,nuevo_nombre,nuevo_costo,nuevo_margen,precio_venta,ali)
                else:
                    ali+=[[matriz_ali[i-1][0],cant]]
                    print("")
                    print("Se agregaron los alimentos con exito")
                    print("")
                    return modificar_combo_aux(nombre,nuevo_nombre,nuevo_costo,nuevo_margen,precio_venta,ali)
            else:
                print("")
                print("El alimento se debe seleccionar segun el indice que lo representa y las cantidades deben ser positivas y enteras")
        else:
            print("")
            print("El alimento se debe seleccionar segun el indice que lo representa y las cantidades deben ser positivas y enteras")
            
    elif tarea=="2":
        print("")
        print("___Alimentos listos para incluir___")
        mostrar_ali_incluido(ali,1)
        i=input("Ingrese el indice del alimento que desea eliminar de la inclucion: ")
        cant=input("Ingrese la cantidad que desea eliminar: ")
        if es_entero(i) and es_entero(cant):
            i=int(i)
            cant=int(cant)
            if (i<=largo_lista(ali) and i>0) and cant>0:
                ali=restar_ali_combo(ali[i-1],ali,cant,[])
                print("")
                print("Se elimino correctamente")
                print("")
                return modificar_combo_aux(nombre,nuevo_nombre,nuevo_costo,nuevo_margen,precio_venta,ali)
            else:
                print("")
                print("El alimento se debe seleccionar segun el indice que lo representa y la debe ser un numero entero y positivo")
        else:
            print("")
            print("El alimento se debe seleccionar segun el indice que lo representa y la cantidad debe ser un numero entero y positivo")
            
    elif tarea=="3":
        print("")
        print("___Alimentos listos para incluir___")
        mostrar_ali_incluido(ali,1)
        return modificar_combo_aux(nombre,nuevo_nombre,nuevo_costo,nuevo_margen,precio_venta,ali)
    
    elif tarea=="4":
        if ali==[]:
            print("")
            print("no puede finalizar con la modificacion porque no hay ingresado un alimento")
        else:
            archivo=open("combos.txt","r")
            listatxt=archivo.readlines()
            matriz=crearMatriz(listatxt,[])
            archivo.close()

            archivo2=open("combos.txt","w")
            return fin_modificar_combo(matriz,archivo2,nombre,nuevo_nombre,nuevo_costo,nuevo_margen,precio_venta,ali)
    else:
        print("")
        print("La opcion que ingreso no es valida")
        print("")
        return modificar_combo_aux(nombre,nuevo_nombre,nuevo_costo,nuevo_margen,precio_venta,ali)

#funcion para finalizar la modificaion de los combos al archivo donde se almacenan
def fin_modificar_combo(matriz,archivo,nombre,nuevo_nombre,nuevo_costo,nuevo_margen,precio_venta,ali):
    if matriz==[]:
        archivo.close()
        print("")
        print("Se modificaron los datos con exito")
        print("")
    else:
        if matriz[0][0]==nombre:
            archivo.write(str(nuevo_nombre)+","+str(nuevo_costo)+","+str(nuevo_margen)+","+str(precio_venta))
            modificar_comboAux_ali(archivo,ali)
            return fin_modificar_combo(matriz[1:],archivo,nombre,nuevo_nombre,nuevo_costo,nuevo_margen,precio_venta,ali)
        else:
            archivo.write(matriz[0][0]+","+matriz[0][1]+","+matriz[0][2]+","+matriz[0][3])
            neo_matriz=matriz[0]
            eliminar_comboAux_ali(archivo,neo_matriz[4:])
            return fin_modificar_combo(matriz[1:],archivo,nombre,nuevo_nombre,nuevo_costo,nuevo_margen,precio_venta,ali)
            

#################################################################################
#funcion para agregar los alimentos de los combos al archivo en modificar
def modificar_comboAux_ali(archivo,lista):
    if lista==[]:
        archivo.write("\n")
    else:
        archivo.write(",")
        archivo.write(str(lista[0][0]))
        archivo.write(",")
        archivo.write(str(lista[0][1]))
        return modificar_comboAux_ali(archivo,lista[1:])

#################################################################################
#funcion que muestra los alimentos que se incluiran a un combo con un indice
#el indice comienza en 1
def mostrar_alimento_indice(lista,i):
    if lista==[]:
        print("")
    else:
        print(str(i)+". ",lista[0][0])
        return mostrar_alimento_indice(lista[1:],i+1)
    
################################################################################
#menu de opciones generales
#E: solicitud de la tarea de opciones generales por medio de un indice relacionado a la tarea deseada
#S: redireccion a 1. Crear usuario, 2. Consultar alimento, 3.Consulta de puntos e historicos de redenciones, 4. Consulta de ordenes o 5. Salir
#R: si la opcion que el usuario ingresa no es valida se le hara saber y se le pedira  que lo intente nuevamente
def opciones_generales():
    print("______Opciones Generales______")
    print("1. Crear usuario")
    print("2. Consultar alimentos")
    print("3. Consulta de puntos e historicos de redenciones")
    print("4. Consulta de ordenes")
    print("5. Volver")

    tarea=input("Digite la tarea que desea realizar: ")
    if tarea=="1":
        print("")
        operacion=crear_user()
        operacion
        print("")
        return opciones_generales()
    elif tarea=="2":
        print("")
        operacion=consultar_alimento()
        operacion
        print("")
        return opciones_generales()
    elif tarea=="3":
        print("")
        print("Esta opcion no esta disponible")
        print("")
        return opciones_generales()
    elif tarea=="4":
        print("")
        print("Esta opcion no esta disponible")
        print("")
        return opciones_generales()
    elif tarea=="5":
        print("")
        return menu_principal()
    else:
        print("")
        print("La opcion que ingreso no es valida")
        print("")
        return opciones_generales()

#################################################################################
#funcion para crear un usuario
#E: codigo de usario, nombre y fecha de nacimiento
#S: la adicion de los datos al archivo de texto
#R: no pueden existir dos usuarios con el mismo codigo, todo lo relacionado a la fecha de nacimiento debe ser numeros enteros
def crear_user():
    texto="___Usuarios almacenados___"
    archivo="usuarios.txt"
    mostrar(archivo,texto)
    print("______Crear Usuario______")
    codigo=input("Ingrese un codigo de usuario: ")
    
    archivo=open("usuarios.txt","r")
    listatxt=archivo.readlines()
    matriz=crearMatriz(listatxt,[])
    if esta(matriz, codigo):
        print("")
        print("No pueden existir dos usuarios con el mismo codigo")
    else:
        nombre=input("Ingrese un nombre: ")
        dia=input("Ingrese el dia de nacimiento: ")
        mes=input("Ingrese el mes de nacimiento: ")
        epoca=input("Ingrese el año de nacimiento: ")
        
        if es_entero(dia) and es_entero(mes) and es_entero(epoca):
            dia=int(dia)
            mes=int(mes)
            epoca=int(epoca)
            if epoca>=1920 or epoca<=2019:
                if (mes==1 or mes==3 or mes==5 or mes==7 or mes==8 or mes==10 or mes==12) and (dia>=1 or dia <= 31):
                    return incluir_usuario(codigo,nombre,[str(dia),str(mes),str(epoca)])
                elif (mes==4 or mes==6 or mes==9 or  mes==11) and (dia>=1 or dia<=30):
                    return incluir_usuario(codigo,nombre,[str(dia),str(mes),str(epoca)])
                elif mes==2 and (dia>=1 or dia <= 28):
                    return incluir_usuario(codigo,nombre,[str(dia),str(mes),str(epoca)])
                else:
                    print("")
                    print("La fecha que ingreso no es valida")
            else:
                print("")
                print("Lafecha que ingreso no es valida")
        else:
            print("")
            print("Todos los datos relacionados a la fecha de nacimiento deben ser enteros")

#funcion para guardar la informacion de un nuevo usuario
#E: el codigo del usuario, el nombre del usuario y la fecha de nacimiento del usuario en una lista
#S: el archivo actualizado con los datos introducidos junto a10 puntos para el usuario
#R: el archivo se cerrara una vez todos los elementos se ingresaran
def incluir_usuario(codigo,nombre,fecha):
    archivo=open("usuarios.txt","a")
    archivo.write(codigo)
    archivo.write(",")
    archivo.write(nombre)
    archivo.write(",")
    archivo.write(fecha[0]+"/"+fecha[1]+"/"+fecha[2])
    archivo.write(",")
    archivo.write(str(10))
    archivo.write("\n")
    archivo.close()
    print("")
    print("Se ingresaron los datos con exito")

#################################################################################
#Muestra una lista de los alimentos y combos, mostrando toda su información, detallada por línea
#podrá filtrar por tipo de alimento y combos
def consultar_alimento():
    print("______Consulta de alimentos_______")
    print("1. Mostrar alimentos")
    print("2. Mostrar combos")
    print("3. Volver")
    tarea=input("Ingrese la tarea que desea realizar: ")
    if tarea=="1":    
        archivo="alimento.txt"
        texto="___Alimentos almacenados___"  
        mostrar(archivo,texto)
        return consultar_alimento()
    elif tarea=="2":
        archivo="combos.txt"
        texto="___Combos almacenados___"   
        mostrar(archivo,texto)
        return consultar_alimento()
    elif tarea=="3":
        print("")
        return opciones_generales()        
    else:
        print("")
        print("La tarea que desea realizar no es valida")
        print("")
  
################################################################################
#funcion para verificar que un elemento de un input es entero
def es_entero(num):
    try:
        num=int(num)
        return isinstance(num,int)
    except:
        return False
################################################################################
menu_principal()
